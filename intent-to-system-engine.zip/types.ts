export interface Stage1IntentAnalysis {
  explicitGoals: string[];
  implicitGoals: string[];
  constraints: string[];
  emotionalFactors: string[];
  assumptions: string[];
  missingInformation: string[];
}

export interface GoalNode {
  id: string;
  title: string;
  type: 'abstract' | 'concrete' | 'milestone';
  children?: GoalNode[];
}

export interface Stage2GoalDecomposition {
  rootGoal: GoalNode;
}

export interface Stage3Strategy {
  corePhilosophy: string;
  resourceAllocation: string;
  constraintsAdaptation: string;
  learningFocus: string;
}

export interface RoadmapStep {
  id: string;
  phase: string;
  objective: string;
  actions: string[];
  tools: string[];
  timeEstimate: string;
  successCriteria: string[];
  decisionCheckpoint: string;
}

export interface Stage4Roadmap {
  steps: RoadmapStep[];
}

export interface RiskItem {
  risk: string;
  impact: 'Low' | 'Medium' | 'High';
  mitigation: string;
  earlyWarning: string;
}

export interface Stage5Risks {
  keyRisks: RiskItem[];
  criticalAssumptions: string[];
  fallbackOptions: string[];
}

export interface Stage6Summary {
  whyThisFits: string;
  howConstraintsShaped: string;
  immediateFocus: string;
}

export interface ReasoningResult {
  stage1: Stage1IntentAnalysis;
  stage2: Stage2GoalDecomposition;
  stage3: Stage3Strategy;
  stage4: Stage4Roadmap;
  stage5: Stage5Risks;
  stage6: Stage6Summary;
}

export type ProcessingStatus = 'idle' | 'analyzing' | 'strategizing' | 'complete' | 'error';

export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}
