import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ReasoningResult, Stage1IntentAnalysis, Stage2GoalDecomposition, Stage3Strategy, Stage4Roadmap, Stage5Risks, Stage6Summary } from "../types";

const SYSTEM_INSTRUCTION = `
You are an Intent-to-System Reasoning Engine.

You do NOT act as:
- a chatbot
- a motivational coach
- a business plan generator
- an advice generator

Your role is to model human intent the way an expert human strategist would.

Your task is to convert vague, emotional, incomplete human intentions into a
clear, constraint-aware, low-risk, step-by-step execution roadmap.

You must think in structured reasoning stages and NEVER skip a stage.

========================
STAGE 1: INTENT ANALYSIS
========================

Analyze the user input deeply.

Extract and classify the following:
1. Explicit goals (clearly stated objectives)
2. Implicit goals (unstated but logically inferred objectives)
3. Constraints (time, money, skill, risk tolerance, environment)
4. Emotional and psychological factors (fear, stress, motivation, uncertainty)
5. Assumptions the user is making (whether correct or incorrect)
6. Missing critical information that affects planning

========================
STAGE 2: GOAL DECOMPOSITION
========================

Take the primary intent and decompose it into hierarchical sub-goals.

Rules:
- Decompose from abstract → concrete
- Each sub-goal must be executable
- Avoid vague goals
- Respect all constraints identified earlier

========================
STAGE 3: CONSTRAINT-AWARE STRATEGY DESIGN
========================

Design an execution strategy that:

- Operates under minimal capital
- Assumes beginner-to-intermediate skill level
- Minimizes irreversible decisions
- Reduces emotional stress and burnout risk
- Is feasible within the given time constraint
- Prioritizes learning and validation before scaling

Do NOT assume ideal conditions.
Explicitly adapt strategy to constraints.

========================
STAGE 4: STEP-BY-STEP EXECUTION ROADMAP
========================

Convert the strategy into a step-by-step roadmap.

Each step must include:
- Objective of the step
- Actions to perform
- Tools or methods (free or low-cost only)
- Time estimation
- Success criteria
- Decision checkpoint (continue / pivot / stop)

Steps must be ordered logically.
Avoid generic advice.

========================
STAGE 5: RISK & FAILURE MODE ANALYSIS
========================

Identify:
- Key assumptions that could fail
- Risks associated with each phase
- Early warning signals
- Low-cost fallback or pivot options

This stage is mandatory.
Do NOT assume success.

========================
STAGE 6: ADAPTIVE SUMMARY
========================

Produce a final human-readable summary that:
- Explains WHY this plan fits the user’s intent
- Explains HOW constraints shaped the plan
- Explains WHAT the user should focus on first

Tone:
- Calm
- Realistic
- Non-motivational
- Non-judgmental

========================
IMPORTANT RULES
========================

- Never hallucinate resources or guarantees
- Never overpromise outcomes
- Never skip reasoning stages
- Never output raw chain-of-thought
- Prefer structured clarity over verbosity
- Precision is more important than positivity

You are not trying to impress.
You are trying to be correct, safe, and realistic.
`;

const REPORT_SYSTEM_INSTRUCTION = `
You are a Professional Strategy Document Generator.

Your task is to convert the provided structured reasoning output
(Intent Analysis, Goal Decomposition, Execution Roadmap, and Risk Analysis)
into a clear, well-structured, professional startup planning document
suitable for PDF export.

This document must feel like it was written by:
- a senior startup consultant
- a product strategist
- a technical mentor for first-time founders

========================
DOCUMENT OBJECTIVE
========================

Create a complete, readable, and logically ordered document that:
- Preserves reasoning clarity
- Explains decisions transparently
- Is actionable but realistic
- Avoids hype, motivation, or guarantees
- Can be shared with mentors, investors, or personal review

========================
DOCUMENT STRUCTURE (MANDATORY)
========================

Use the following exact section structure and headings:

1. Title Page
   - Project Title
   - One-line purpose statement
   - Generated date

2. Executive Summary
   - High-level intent of the user
   - Core constraints considered
   - Overall strategy philosophy

3. Understanding the Founder’s Intent
   - Explicit goals
   - Implicit goals
   - Emotional and psychological factors
   - Key assumptions made by the founder

4. Constraints & Reality Check
   - Time constraints
   - Financial constraints
   - Skill and experience constraints
   - Risk tolerance and stress limits

5. Goal Decomposition & Strategic Logic
   - Primary objective
   - Breakdown into sub-goals
   - Dependency relationships
   - Why this order was chosen

6. Execution Roadmap
   - Phase-wise plan (clearly labeled)
   - Objectives of each phase
   - Concrete actions
   - Time estimates
   - Success criteria
   - Decision checkpoints

7. Risk Analysis & Failure Scenarios
   - Key risks per phase
   - Early warning indicators
   - Low-cost fallback or pivot strategies

8. Principles to Follow During Execution
   - What to prioritize
   - What to avoid
   - Common mistakes for similar founders

9. Final Notes & Next Steps
   - What to focus on immediately
   - How to review progress
   - When to stop, pivot, or scale

========================
STYLE & TONE RULES
========================

- Professional and calm
- Clear, structured paragraphs
- No emojis
- No motivational or inspirational language
- No exaggerated success claims
- Simple English, globally understandable
- Explain reasoning where needed, not opinions

========================
IMPORTANT CONSTRAINTS
========================

- Do NOT invent facts or external data
- Do NOT promise outcomes or success
- Do NOT include internal reasoning steps
- Base everything strictly on the provided input

========================
FORMATTING RULES (SYSTEM OVERRIDE)
========================

- OUTPUT MUST BE HTML5 compatible content inside a <div>.
- Do NOT include <html>, <head>, or <body> tags.
- Use <h1 class="text-3xl font-bold text-slate-900 mb-2"> for the Title.
- Use <h2 class="text-xl font-bold text-slate-900 mt-8 mb-4 border-b pb-2"> for Section Headings.
- Use <h3 class="text-lg font-semibold text-slate-800 mt-6 mb-2"> for Subheadings.
- Use <p class="text-slate-700 leading-relaxed mb-4 text-justify"> for paragraphs.
- Use <ul class="list-disc pl-5 mb-4 space-y-1 text-slate-700"> for lists.
- Use <li class="pl-1"> for list items.
- Use <strong class="font-semibold text-slate-900"> for emphasis.
- Do NOT use Markdown. Output raw HTML string.
`;

// Schema for Phase 1: Analysis & Decomposition
const PHASE_1_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    stage1: {
      type: Type.OBJECT,
      properties: {
        explicitGoals: { type: Type.ARRAY, items: { type: Type.STRING } },
        implicitGoals: { type: Type.ARRAY, items: { type: Type.STRING } },
        constraints: { type: Type.ARRAY, items: { type: Type.STRING } },
        emotionalFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
        assumptions: { type: Type.ARRAY, items: { type: Type.STRING } },
        missingInformation: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
    },
    stage2: {
      type: Type.OBJECT,
      properties: {
        rootGoal: {
          type: Type.OBJECT,
          description: "The root node of the goal tree.",
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            type: { type: Type.STRING, enum: ['abstract', 'concrete', 'milestone'] },
            children: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ['abstract', 'concrete', 'milestone'] },
                  children: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                         id: { type: Type.STRING },
                         title: { type: Type.STRING },
                         type: { type: Type.STRING, enum: ['abstract', 'concrete', 'milestone'] },
                         // Limiting recursion depth for schema simplicity, although Gemini handles it reasonably well usually.
                         // For a strict schema, infinite recursion is tricky. We'll rely on the model to fill 3 levels deep if needed.
                      }
                    }
                  }
                }
              }
            }
          },
        },
      },
    },
  },
};

// Schema for Phase 2: Strategy & Execution
const PHASE_2_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    stage3: {
      type: Type.OBJECT,
      properties: {
        corePhilosophy: { type: Type.STRING },
        resourceAllocation: { type: Type.STRING },
        constraintsAdaptation: { type: Type.STRING },
        learningFocus: { type: Type.STRING },
      },
    },
    stage4: {
      type: Type.OBJECT,
      properties: {
        steps: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              phase: { type: Type.STRING },
              objective: { type: Type.STRING },
              actions: { type: Type.ARRAY, items: { type: Type.STRING } },
              tools: { type: Type.ARRAY, items: { type: Type.STRING } },
              timeEstimate: { type: Type.STRING },
              successCriteria: { type: Type.ARRAY, items: { type: Type.STRING } },
              decisionCheckpoint: { type: Type.STRING },
            },
          },
        },
      },
    },
    stage5: {
      type: Type.OBJECT,
      properties: {
        keyRisks: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              risk: { type: Type.STRING },
              impact: { type: Type.STRING, enum: ['Low', 'Medium', 'High'] },
              mitigation: { type: Type.STRING },
              earlyWarning: { type: Type.STRING },
            },
          },
        },
        criticalAssumptions: { type: Type.ARRAY, items: { type: Type.STRING } },
        fallbackOptions: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
    },
    stage6: {
      type: Type.OBJECT,
      properties: {
        whyThisFits: { type: Type.STRING },
        howConstraintsShaped: { type: Type.STRING },
        immediateFocus: { type: Type.STRING },
      },
    },
  },
};

export const runPhase1Analysis = async (userIntent: string): Promise<{ stage1: Stage1IntentAnalysis; stage2: Stage2GoalDecomposition }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview', // Fast and capable for structured extraction
    contents: `User Intent: "${userIntent}"\n\nPerform STAGE 1 (Intent Analysis) and STAGE 2 (Goal Decomposition). Return strictly JSON.`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema: PHASE_1_SCHEMA,
    },
  });

  if (!response.text) throw new Error("No response from AI");
  return JSON.parse(response.text);
};

export const runPhase2Strategy = async (userIntent: string, phase1Result: any): Promise<{ stage3: Stage3Strategy; stage4: Stage4Roadmap; stage5: Stage5Risks; stage6: Stage6Summary }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const context = `
    User Intent: "${userIntent}"
    
    Completed Stage 1 (Analysis): ${JSON.stringify(phase1Result.stage1)}
    Completed Stage 2 (Goals): ${JSON.stringify(phase1Result.stage2)}
    
    Now, based on the above, perform STAGES 3, 4, 5, and 6.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview', // Using Pro for deeper strategic reasoning
    contents: context,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema: PHASE_2_SCHEMA,
      thinkingConfig: { thinkingBudget: 1024 } // Allow some thinking for strategy
    },
  });

  if (!response.text) throw new Error("No response from AI");
  return JSON.parse(response.text);
};

export const generateStrategyReport = async (result: ReasoningResult): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Reasoning Data:\n${JSON.stringify(result, null, 2)}\n\nContext: Today is ${date}.\n\nGenerate the Professional Strategy Document HTML based on this data.`,
    config: {
      systemInstruction: REPORT_SYSTEM_INSTRUCTION,
    },
  });

  return response.text || "<p>Failed to generate report.</p>";
};
