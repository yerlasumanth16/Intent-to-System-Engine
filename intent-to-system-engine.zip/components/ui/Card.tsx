import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'outline' | 'glass';
}

export const Card: React.FC<CardProps> = ({ className, variant = 'default', children, ...props }) => {
  const baseStyles = "rounded-xl p-6 transition-all duration-200";
  const variants = {
    default: "bg-slate-800/50 border border-slate-700/50 shadow-lg backdrop-blur-sm",
    outline: "bg-transparent border border-slate-700",
    glass: "bg-white/5 border border-white/10 backdrop-blur-md",
  };

  return (
    <div className={twMerge(baseStyles, variants[variant], className)} {...props}>
      {children}
    </div>
  );
};

export const CardHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, children, ...props }) => (
  <div className={twMerge("mb-4", className)} {...props}>{children}</div>
);

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({ className, children, ...props }) => (
  <h3 className={twMerge("text-lg font-semibold text-slate-100", className)} {...props}>{children}</h3>
);

export const CardContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, children, ...props }) => (
  <div className={twMerge("text-slate-300", className)} {...props}>{children}</div>
);