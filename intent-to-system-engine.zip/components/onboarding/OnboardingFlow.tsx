import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { clsx } from 'clsx';
import { X, ChevronRight, Check, HelpCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface OnboardingStep {
  targetId: string | null;
  title: string;
  content: string;
  position: 'center' | 'bottom-left' | 'bottom';
}

export const OnboardingFlow: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  // Using null to signify "not calculated yet" or "off screen"
  const [position, setPosition] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const { isAuthenticated } = useAuth();

  const steps = useMemo<OnboardingStep[]>(() => {
    const s: OnboardingStep[] = [
      {
        targetId: null,
        title: "Welcome to Reasoning Engine",
        content: "This tool models expert strategic thinking to turn your vague ideas into concrete, low-risk execution plans.",
        position: 'center'
      }
    ];

    if (!isAuthenticated) {
      s.push({
        targetId: 'login-btn',
        title: "Sign Up or Log In",
        content: "Create a free account to securely save your strategic maps and access previous sessions.",
        position: 'bottom-left'
      });
    }

    s.push(
      {
        targetId: 'intent-input',
        title: "Describe Your Intent",
        content: "Start here. Be honest about your goal, your fears, and your constraints. The more raw the input, the better the strategy.",
        position: 'bottom'
      },
      {
        targetId: 'execute-btn',
        title: "Generate Strategy",
        content: "Click execute to let the AI decompose your goal, analyze risks, and build a step-by-step roadmap.",
        position: 'bottom-left'
      }
    );
    return s;
  }, [isAuthenticated]);

  // Manual Trigger Listener
  useEffect(() => {
    const handleStart = () => {
      setCurrentStep(0);
      setIsVisible(true);
    };
    window.addEventListener('ise_start_onboarding', handleStart);
    return () => window.removeEventListener('ise_start_onboarding', handleStart);
  }, []);

  // Initial Auto-Start check
  useEffect(() => {
    const hasSeen = localStorage.getItem('ise_onboarding_completed');
    if (!hasSeen) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const updatePosition = useCallback(() => {
    if (!isVisible) return;
    
    // Ensure current step is within bounds
    if (currentStep >= steps.length) {
      // If steps changed and we are out of bounds (unlikely but safe to handle)
      return; 
    }

    const step = steps[currentStep];
    if (step.targetId) {
      const element = document.getElementById(step.targetId);
      if (element) {
        const rect = element.getBoundingClientRect();
        // Use viewport coordinates since we are using fixed positioning
        setPosition({
          top: rect.top,
          left: rect.left,
          width: rect.width,
          height: rect.height
        });
      } else {
         // Element not found
         setPosition(null);
      }
    } else {
      setPosition(null);
    }
  }, [currentStep, isVisible, steps]);

  // Scroll target into view when step changes
  useEffect(() => {
    if (isVisible) {
      // Ensure we don't access out of bounds if steps changed
      const safeStepIndex = Math.min(currentStep, steps.length - 1);
      if (safeStepIndex !== currentStep) {
        setCurrentStep(safeStepIndex);
        return;
      }

      const step = steps[safeStepIndex];
      if (step.targetId) {
        const element = document.getElementById(step.targetId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          // We need to wait for scroll to finish or update continuously. 
          // A simple timeout helps catch the end of smooth scroll roughly.
          setTimeout(updatePosition, 500); 
        }
      }
      updatePosition();
    }
  }, [currentStep, isVisible, updatePosition, steps]);

  // continuous position update on scroll/resize
  useEffect(() => {
    if (!isVisible) return;
    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition, true); // Capture phase to catch all scrolls
    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [isVisible, updatePosition]);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    localStorage.setItem('ise_onboarding_completed', 'true');
  };

  if (!isVisible) return null;

  const step = steps[Math.min(currentStep, steps.length - 1)];
  // Calculate tooltip position based on target rect (if available)
  const tooltipStyle = (step.targetId && position) ? {
      top: position.top + position.height + 20,
      left: step.position === 'bottom-left' ? position.left + position.width - 320 : position.left
  } : {};

  // If we have a target but no position yet (e.g. obscured), hide momentarily or fallback
  const showSpotlight = step.targetId && position;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-[60] bg-slate-950/70 transition-opacity duration-500 animate-in fade-in">
        
        {/* Spotlight Effect */}
        {showSpotlight && (
            <div 
                className="absolute transition-all duration-300 ease-out border-2 border-indigo-500 rounded-lg shadow-[0_0_0_9999px_rgba(2,6,23,0.85)] pointer-events-none"
                style={{
                    top: position!.top - 8,
                    left: position!.left - 8,
                    width: position!.width + 16,
                    height: position!.height + 16,
                }}
            />
        )}
      </div>

      {/* Tooltip Card */}
      <div 
        className={clsx(
          "fixed z-[70] max-w-sm w-full transition-all duration-500",
          step.position === 'center' ? "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" : ""
        )}
        style={step.position !== 'center' ? tooltipStyle : {}}
      >
        <div className="bg-slate-900 border border-slate-700 shadow-2xl rounded-xl p-6 relative mx-4 sm:mx-0">
            <button 
                onClick={handleComplete}
                className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors"
                title="Close Tutorial"
            >
                <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 text-xs font-mono font-bold border border-indigo-500/30">
                    {Math.min(currentStep + 1, steps.length)}
                </span>
                <h3 className="font-bold text-slate-100">{step.title}</h3>
            </div>
            
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
                {step.content}
            </p>

            <div className="flex items-center justify-between">
                <div className="flex gap-1">
                    {steps.map((_, i) => (
                        <div 
                            key={i} 
                            className={`w-1.5 h-1.5 rounded-full transition-colors ${i === currentStep ? 'bg-indigo-500' : 'bg-slate-700'}`}
                        />
                    ))}
                </div>
                <div className="flex gap-3">
                    {currentStep < steps.length - 1 && (
                        <button 
                            onClick={handleComplete}
                            className="text-xs font-medium text-slate-500 hover:text-slate-300 transition-colors"
                        >
                            Skip
                        </button>
                    )}
                    <button 
                        onClick={handleNext}
                        className="flex items-center gap-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-500 px-4 py-1.5 rounded-lg transition-colors shadow-lg shadow-indigo-500/20"
                    >
                        {currentStep === steps.length - 1 ? 'Finish' : 'Next'}
                        {currentStep === steps.length - 1 ? <Check className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                    </button>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};