import React from 'react';
import { X, Printer, Download, FileText } from 'lucide-react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: string;
}

export const ReportModal: React.FC<ReportModalProps> = ({ isOpen, onClose, content }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    // Create a hidden iframe to print
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.body.appendChild(iframe);
    
    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(`
        <html>
          <head>
            <title>Strategy Document</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <style>
              body { background: white; padding: 40px; font-family: sans-serif; }
              @media print { 
                body { padding: 0; }
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            ${content}
            <script>
              window.onload = function() { window.print(); window.onafterprint = function(){ window.parent.document.body.removeChild(window.frameElement); } }
            </script>
          </body>
        </html>
      `);
      doc.close();
    }
  };

  const handleDownload = () => {
    const blob = new Blob([`
      <html>
        <head>
          <title>Strategy Document</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <style>body { background: white; padding: 40px; font-family: sans-serif; max-width: 800px; margin: 0 auto; }</style>
        </head>
        <body>${content}</body>
      </html>
    `], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'strategy-report.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 w-full max-w-4xl h-[90vh] flex flex-col rounded-xl shadow-2xl border border-slate-800 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 rounded-lg">
               <FileText className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100">Strategy Document</h3>
              <p className="text-xs text-slate-500">Generated Professional Report</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm transition-colors border border-slate-700"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Print</span>
            </button>
            <button 
              onClick={handleDownload}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm transition-colors shadow-lg shadow-indigo-500/20"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Download</span>
            </button>
            <div className="w-px h-6 bg-slate-800 mx-2" />
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-500 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Preview Area - Paper Style */}
        <div className="flex-1 overflow-auto bg-slate-950/50 p-4 sm:p-8 flex justify-center">
          <div className="w-full max-w-[210mm] bg-white text-slate-900 p-[20mm] shadow-xl min-h-[297mm]">
            <div 
              className="prose prose-slate max-w-none"
              dangerouslySetInnerHTML={{ __html: content }} 
            />
          </div>
        </div>

      </div>
    </div>
  );
};