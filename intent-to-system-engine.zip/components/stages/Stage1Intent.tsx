import React from 'react';
import { Stage1IntentAnalysis } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Target, AlertTriangle, EyeOff, Heart, Lock, HelpCircle } from 'lucide-react';

export const Stage1Intent: React.FC<{ data: Stage1IntentAnalysis }> = ({ data }) => {
  const sections = [
    { title: 'Explicit Goals', icon: <Target className="w-5 h-5 text-emerald-400" />, items: data.explicitGoals },
    { title: 'Implicit Goals', icon: <EyeOff className="w-5 h-5 text-indigo-400" />, items: data.implicitGoals },
    { title: 'Constraints', icon: <Lock className="w-5 h-5 text-amber-400" />, items: data.constraints },
    { title: 'Emotional Factors', icon: <Heart className="w-5 h-5 text-rose-400" />, items: data.emotionalFactors },
    { title: 'Assumptions', icon: <AlertTriangle className="w-5 h-5 text-orange-400" />, items: data.assumptions },
    { title: 'Missing Info', icon: <HelpCircle className="w-5 h-5 text-blue-400" />, items: data.missingInformation },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {sections.map((section, idx) => (
        <Card key={idx} className="bg-slate-900/40 hover:bg-slate-800/60 border-slate-800 hover:border-slate-700">
          <CardHeader className="flex flex-row items-center gap-2 mb-3">
            {section.icon}
            <CardTitle className="text-base font-medium text-slate-200">{section.title}</CardTitle>
          </CardHeader>
          <CardContent>
            {section.items && section.items.length > 0 ? (
              <ul className="space-y-2">
                {section.items.map((item, i) => (
                  <li key={i} className="text-sm text-slate-400 leading-relaxed flex items-start gap-2">
                    <span className="block w-1 h-1 mt-2 rounded-full bg-slate-600 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-600 italic">None detected</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};