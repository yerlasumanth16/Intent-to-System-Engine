import React from 'react';
import { Stage4Roadmap } from '../../types';
import { CheckCircle2, Clock, Hammer, Flag, AlertOctagon } from 'lucide-react';

export const Stage4RoadmapView: React.FC<{ data: Stage4Roadmap }> = ({ data }) => {
  return (
    <div className="relative space-y-8 pl-4 md:pl-0 animate-in fade-in duration-1000">
      {/* Connector Line */}
      <div className="absolute left-8 top-4 bottom-4 w-0.5 bg-slate-800 hidden md:block" />

      {data.steps.map((step, index) => (
        <div key={index} className="relative flex flex-col md:flex-row gap-6 md:items-start group">
          
          {/* Timeline Node */}
          <div className="absolute left-8 -translate-x-1/2 w-4 h-4 rounded-full bg-slate-900 border-2 border-indigo-500 z-10 hidden md:block group-hover:bg-indigo-500 transition-colors" />

          {/* Time & Phase Label (Left Side on Desktop) */}
          <div className="md:w-1/4 md:text-right md:pr-12 pt-1">
            <h3 className="text-indigo-400 font-mono text-sm mb-1">{step.phase}</h3>
            <div className="flex items-center md:justify-end gap-2 text-slate-500 text-xs">
              <Clock className="w-3 h-3" />
              <span>{step.timeEstimate}</span>
            </div>
          </div>

          {/* Card Content (Right Side) */}
          <div className="flex-1 bg-slate-900/50 border border-slate-800 rounded-lg p-5 hover:border-indigo-500/30 transition-all">
            <h4 className="text-lg font-semibold text-slate-200 mb-3">{step.objective}</h4>
            
            <div className="space-y-4">
              {/* Actions */}
              <div>
                <span className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2 block">Actions</span>
                <ul className="space-y-2">
                  {step.actions.map((action, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mt-1.5 flex-shrink-0" />
                      {action}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tools & Success Criteria Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                   <div className="flex items-center gap-2 mb-2 text-xs font-mono text-slate-500 uppercase tracking-wider">
                      <Hammer className="w-3 h-3" /> Tools
                   </div>
                   <div className="flex flex-wrap gap-2">
                      {step.tools.map((tool, t) => (
                        <span key={t} className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-400 border border-slate-700/50">{tool}</span>
                      ))}
                   </div>
                </div>
                <div>
                   <div className="flex items-center gap-2 mb-2 text-xs font-mono text-slate-500 uppercase tracking-wider">
                      <Flag className="w-3 h-3" /> Success Criteria
                   </div>
                   <ul className="space-y-1">
                      {step.successCriteria.map((crit, c) => (
                        <li key={c} className="text-xs text-emerald-400/80 flex items-center gap-1.5">
                           <CheckCircle2 className="w-3 h-3" /> {crit}
                        </li>
                      ))}
                   </ul>
                </div>
              </div>

              {/* Checkpoint */}
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-start gap-3 bg-amber-950/10 -mx-5 -mb-5 p-4 rounded-b-lg">
                <AlertOctagon className="w-5 h-5 text-amber-500 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-amber-500 uppercase tracking-wide">Decision Checkpoint</span>
                  <p className="text-sm text-amber-200/80 mt-1">{step.decisionCheckpoint}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};