import React from 'react';
import { Stage6Summary } from '../../types';
import { Quote } from 'lucide-react';

export const Stage6SummaryView: React.FC<{ data: Stage6Summary }> = ({ data }) => {
  return (
    <div className="max-w-3xl mx-auto space-y-12 py-8 animate-in fade-in duration-1000">
      
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-white tracking-tight">System Synthesis</h2>
        <div className="h-1 w-20 bg-indigo-500 mx-auto rounded-full" />
      </div>

      <div className="space-y-8">
        <section>
            <h3 className="text-indigo-400 font-mono text-sm uppercase mb-3">Why this fits your intent</h3>
            <p className="text-lg text-slate-200 leading-relaxed font-light">{data.whyThisFits}</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <section className="bg-slate-900/50 p-6 rounded-lg border border-slate-800">
                <h3 className="text-amber-400 font-mono text-sm uppercase mb-3">Constraints Impact</h3>
                <p className="text-base text-slate-300 leading-relaxed">{data.howConstraintsShaped}</p>
            </section>
            
            <section className="bg-indigo-950/20 p-6 rounded-lg border border-indigo-500/20">
                <h3 className="text-emerald-400 font-mono text-sm uppercase mb-3">Immediate Focus</h3>
                <p className="text-base text-slate-200 leading-relaxed font-medium">{data.immediateFocus}</p>
            </section>
        </div>
      </div>

      <div className="flex justify-center pt-8 opacity-50">
        <Quote className="w-8 h-8 text-slate-600" />
      </div>

    </div>
  );
};