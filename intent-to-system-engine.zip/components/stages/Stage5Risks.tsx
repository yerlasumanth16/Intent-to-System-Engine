import React from 'react';
import { Stage5Risks } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { AlertTriangle, Shield, Search } from 'lucide-react';

export const Stage5RisksView: React.FC<{ data: Stage5Risks }> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in zoom-in-95 duration-500">
      
      {/* Key Risks Column */}
      <div className="lg:col-span-2 space-y-4">
        <h3 className="text-sm font-mono text-slate-400 uppercase tracking-widest mb-2">Failure Mode Analysis</h3>
        {data.keyRisks.map((risk, idx) => (
          <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col sm:flex-row gap-4 hover:border-rose-900/50 transition-colors group">
            <div className={`shrink-0 w-12 h-12 rounded-full flex items-center justify-center ${risk.impact === 'High' ? 'bg-rose-900/30 text-rose-500' : risk.impact === 'Medium' ? 'bg-orange-900/30 text-orange-500' : 'bg-yellow-900/30 text-yellow-500'}`}>
                <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-slate-200">{risk.risk}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${risk.impact === 'High' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-orange-500/10 text-orange-400 border border-orange-500/20'}`}>
                        {risk.impact.toUpperCase()} IMPACT
                    </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                    <div className="text-sm">
                        <span className="text-slate-500 block text-xs mb-0.5">Mitigation</span>
                        <span className="text-slate-300">{risk.mitigation}</span>
                    </div>
                    <div className="text-sm">
                        <span className="text-slate-500 block text-xs mb-0.5">Early Warning</span>
                        <span className="text-amber-400/80 font-mono text-xs">{risk.earlyWarning}</span>
                    </div>
                </div>
            </div>
          </div>
        ))}
      </div>

      {/* Side Column: Assumptions & Fallbacks */}
      <div className="space-y-6">
        <Card className="border-indigo-500/20 bg-indigo-950/10">
            <CardHeader className="pb-2">
                <CardTitle className="text-sm uppercase tracking-wider text-indigo-400 flex items-center gap-2">
                    <Search className="w-4 h-4" /> Critical Assumptions
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2">
                    {data.criticalAssumptions.map((item, i) => (
                        <li key={i} className="text-sm text-slate-400 border-l-2 border-indigo-500/30 pl-3">
                            {item}
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>

        <Card className="border-emerald-500/20 bg-emerald-950/10">
            <CardHeader className="pb-2">
                <CardTitle className="text-sm uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                    <Shield className="w-4 h-4" /> Pivot / Fallback
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2">
                    {data.fallbackOptions.map((item, i) => (
                        <li key={i} className="text-sm text-slate-400 border-l-2 border-emerald-500/30 pl-3">
                            {item}
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
      </div>

    </div>
  );
};