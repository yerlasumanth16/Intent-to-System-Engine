import React, { useMemo } from 'react';
import * as d3 from 'd3';
import { Stage2GoalDecomposition, GoalNode } from '../../types';

// Helper to convert recursive type to d3 compatible format
const convertToD3 = (node: GoalNode): any => {
  return {
    name: node.title,
    type: node.type,
    children: node.children ? node.children.map(convertToD3) : []
  };
};

export const Stage2Goals: React.FC<{ data: Stage2GoalDecomposition }> = ({ data }) => {
  const containerRef = React.useRef<HTMLDivElement>(null);
  
  const root = useMemo(() => {
    if (!data.rootGoal) return null;
    const hierarchy = d3.hierarchy(convertToD3(data.rootGoal));
    // Set a fixed node size for layout
    const treeLayout = d3.tree().nodeSize([40, 200]); // Height, Width (reversed because we rotate)
    return treeLayout(hierarchy);
  }, [data]);

  // Calculate SVG dimensions based on tree size
  const svgWidth = 800;
  const svgHeight = 500;
  
  // Center the tree
  const translateX = 100;
  const translateY = svgHeight / 2;

  // Flatten links and nodes for rendering
  const links = root ? root.links() : [];
  const nodes = root ? root.descendants() : [];

  return (
    <div className="w-full h-[600px] overflow-auto bg-slate-900/30 rounded-xl border border-slate-800 p-4 relative flex items-center justify-center">
        {/* We use a simple Flex based recursive renderer as fallback if D3 feels too rigid, 
            but here we implement a simple SVG render using D3 coordinates for that 'system' feel */}
        
        <svg width="100%" height="100%" viewBox={`-50 0 ${svgWidth} ${svgHeight}`} className="min-w-[800px] min-h-[500px]">
          <g transform={`translate(${translateX}, 0)`}>
            {/* Links */}
            {links.map((link, i) => {
              // Draw bezier curves
              const d = d3.linkHorizontal()
                .x((d: any) => d.y)
                .y((d: any) => d.x)(link as any);
              
              return (
                <path 
                  key={`link-${i}`} 
                  d={d || ""} 
                  fill="none" 
                  stroke="#334155" 
                  strokeWidth="1.5"
                  className="animate-in fade-in duration-700"
                />
              );
            })}

            {/* Nodes */}
            {nodes.map((node, i) => {
                const isRoot = !node.parent;
                const hasChildren = !!node.children;
                const typeColor = node.data.type === 'abstract' ? '#6366f1' : node.data.type === 'concrete' ? '#10b981' : '#f59e0b';
                
                return (
                  <g key={`node-${i}`} transform={`translate(${node.y},${node.x})`} className="group">
                    {/* Node Circle */}
                    <circle 
                      r={isRoot ? 8 : 5} 
                      fill="#0f172a" 
                      stroke={typeColor} 
                      strokeWidth={2}
                      className="transition-all duration-300 group-hover:scale-125"
                    />
                    
                    {/* Label */}
                    <foreignObject x={isRoot ? -200 : 12} y={-15} width={180} height={40} style={{ overflow: 'visible'}}>
                        <div className={`text-xs px-2 py-1 rounded bg-slate-900/80 border border-slate-700 backdrop-blur-sm text-slate-200 shadow-sm w-max max-w-[200px] whitespace-normal ${isRoot ? 'text-right mr-4 -translate-x-full' : 'text-left'}`}>
                            {node.data.name}
                        </div>
                    </foreignObject>
                  </g>
                )
            })}
          </g>
        </svg>
    </div>
  );
};