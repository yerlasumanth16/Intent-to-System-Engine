import React from 'react';
import { Stage3Strategy as Stage3StrategyType } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Brain, TrendingUp, ShieldAlert, GraduationCap } from 'lucide-react';

export const Stage3Strategy: React.FC<{ data: Stage3StrategyType }> = ({ data }) => {
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-8 duration-700">
      <Card className="bg-gradient-to-br from-slate-900 to-indigo-950/30 border-indigo-500/20">
        <CardHeader className="flex flex-row items-center gap-3">
            <Brain className="w-6 h-6 text-indigo-400" />
            <CardTitle>Core Philosophy</CardTitle>
        </CardHeader>
        <CardContent>
            <p className="text-lg text-slate-200 font-medium leading-relaxed">{data.corePhilosophy}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
            <CardHeader className="flex flex-row items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <CardTitle className="text-base">Resource Allocation</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-slate-400">{data.resourceAllocation}</p>
            </CardContent>
        </Card>

        <Card>
            <CardHeader className="flex flex-row items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-400" />
                <CardTitle className="text-base">Constraint Adaptation</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-slate-400">{data.constraintsAdaptation}</p>
            </CardContent>
        </Card>

        <Card>
            <CardHeader className="flex flex-row items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-400" />
                <CardTitle className="text-base">Learning Focus</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-slate-400">{data.learningFocus}</p>
            </CardContent>
        </Card>
      </div>
    </div>
  );
};