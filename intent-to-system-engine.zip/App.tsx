import React, { useState, useRef, useEffect } from 'react';
import { runPhase1Analysis, runPhase2Strategy, generateStrategyReport } from './services/geminiService';
import { ReasoningResult, ProcessingStatus } from './types';
import { Stage1Intent } from './components/stages/Stage1Intent';
import { Stage2Goals } from './components/stages/Stage2Goals';
import { Stage3Strategy } from './components/stages/Stage3Strategy';
import { Stage4RoadmapView } from './components/stages/Stage4Roadmap';
import { Stage5RisksView } from './components/stages/Stage5Risks';
import { Stage6SummaryView } from './components/stages/Stage6Summary';
import { Brain, Activity, Layers, PlayCircle, AlertTriangle, FileText, Send, LogIn, LogOut, Loader2, FileDown, HelpCircle } from 'lucide-react';
import { clsx } from 'clsx';
import { useAuth } from './contexts/AuthContext';
import { AuthModal } from './components/auth/AuthModal';
import { OnboardingFlow } from './components/onboarding/OnboardingFlow';
import { ReportModal } from './components/report/ReportModal';

const TABS = [
  { id: 'stage1', label: '1. Intent Analysis', icon: Activity },
  { id: 'stage2', label: '2. Goal Tree', icon: Layers },
  { id: 'stage3', label: '3. Strategy', icon: Brain },
  { id: 'stage4', label: '4. Roadmap', icon: PlayCircle },
  { id: 'stage5', label: '5. Risks', icon: AlertTriangle },
  { id: 'stage6', label: '6. Summary', icon: FileText },
];

export default function App() {
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<ProcessingStatus>('idle');
  const [activeTab, setActiveTab] = useState('stage1');
  const [result, setResult] = useState<ReasoningResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  
  // Report Generation State
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [reportContent, setReportContent] = useState<string>('');
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  
  const { user, isAuthenticated, logout } = useAuth();
  
  // To auto-scroll or focus
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSubmit = async () => {
    if (!input.trim()) return;
    
    setStatus('analyzing');
    setError(null);
    setResult(null);
    setReportContent('');
    setActiveTab('stage1');

    try {
      const phase1 = await runPhase1Analysis(input);
      setStatus('strategizing');
      const phase2 = await runPhase2Strategy(input, phase1);
      
      const fullResult: ReasoningResult = {
        ...phase1,
        ...phase2
      };

      setResult(fullResult);
      setStatus('complete');
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);

    } catch (e: any) {
      console.error(e);
      setError(e.message || "An unexpected error occurred during reasoning.");
      setStatus('error');
    }
  };

  const handleGenerateReport = async () => {
    if (!result) return;
    
    // If we already generated it, just open
    if (reportContent) {
      setIsReportOpen(true);
      return;
    }

    setIsGeneratingReport(true);
    try {
      const content = await generateStrategyReport(result);
      setReportContent(content);
      setIsReportOpen(true);
    } catch (e: any) {
      console.error(e);
      // Optional: show toast error
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const startTutorial = () => {
    window.dispatchEvent(new Event('ise_start_onboarding'));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.metaKey) {
        handleSubmit();
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 selection:bg-indigo-500/30">
      <OnboardingFlow />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
      <ReportModal isOpen={isReportOpen} onClose={() => setIsReportOpen(false)} content={reportContent} />

      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Brain className="text-white w-5 h-5" />
            </div>
            <h1 className="font-bold text-lg tracking-tight text-slate-100 hidden sm:block">Intent-to-System <span className="text-slate-500 font-normal">Reasoning Engine</span></h1>
            <h1 className="font-bold text-lg tracking-tight text-slate-100 sm:hidden">I2S <span className="text-slate-500 font-normal">Engine</span></h1>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={startTutorial}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
              title="Start Tutorial"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
            
            <div className="w-px h-6 bg-slate-800" />

            {isAuthenticated && user ? (
              <div className="flex items-center gap-4">
                <div className="hidden sm:flex items-center gap-2 text-sm text-slate-400">
                   <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                   {user.name || user.email}
                </div>
                <button 
                  onClick={() => logout()}
                  className="text-slate-400 hover:text-white transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button 
                id="login-btn"
                onClick={() => setIsAuthOpen(true)}
                className="flex items-center gap-2 text-sm font-medium text-slate-300 hover:text-white transition-colors px-3 py-1.5 rounded hover:bg-slate-800"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-12 space-y-12">
        
        {/* Input Section */}
        <section className="max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-4 mb-10">
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-slate-400">
              Transform intent into execution.
            </h2>
            <p className="text-lg text-slate-400 max-w-xl mx-auto">
              Describe your goal, idea, or vague ambition. The system will deconstruct it into a constraint-aware strategic roadmap.
            </p>
          </div>

          <div className="relative group" id="intent-input">
            <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl opacity-20 group-hover:opacity-40 transition duration-500 blur"></div>
            <div className="relative bg-slate-900 rounded-xl border border-slate-700/50 shadow-2xl overflow-hidden">
                <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="E.g., I want to start a vertical farming business in my garage with $2000, but I have no gardening experience and I'm afraid of failure..."
                    className="w-full h-40 bg-transparent p-6 text-lg text-slate-200 placeholder:text-slate-600 focus:outline-none resize-none font-mono leading-relaxed"
                    disabled={status === 'analyzing' || status === 'strategizing'}
                />
                <div className="bg-slate-800/50 px-4 py-3 flex justify-between items-center border-t border-slate-800">
                    <span className="text-xs text-slate-500 font-mono hidden sm:inline-block">CMD + ENTER to execute</span>
                    <button 
                        id="execute-btn"
                        onClick={handleSubmit}
                        disabled={status === 'analyzing' || status === 'strategizing' || !input.trim()}
                        className="ml-auto flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white px-6 py-2 rounded-lg font-medium transition-all shadow-lg hover:shadow-indigo-500/25 active:scale-95"
                    >
                        {status === 'analyzing' ? 'Phase 1: Analyzing...' : 
                         status === 'strategizing' ? 'Phase 2: Strategizing...' : 
                         (<>Execute <Send className="w-4 h-4" /></>)}
                    </button>
                </div>
            </div>
          </div>
        </section>

        {/* Status Indicators */}
        {(status === 'analyzing' || status === 'strategizing') && (
            <div className="flex flex-col items-center justify-center py-12 space-y-4 animate-pulse">
                <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                <p className="text-indigo-400 font-mono text-sm tracking-widest uppercase">
                    {status === 'analyzing' ? 'Constructing Intent Model...' : 'Simulating Execution Paths...'}
                </p>
            </div>
        )}

        {error && (
            <div className="bg-rose-950/30 border border-rose-900/50 text-rose-300 p-4 rounded-lg text-center max-w-2xl mx-auto">
                <p>{error}</p>
                <button onClick={() => setStatus('idle')} className="text-rose-400 underline mt-2 text-sm hover:text-rose-300">Try Again</button>
            </div>
        )}

        {/* Results Section */}
        {status === 'complete' && result && (
            <div ref={resultRef} className="animate-in fade-in slide-in-from-bottom-12 duration-700">
                
                {/* Navigation and Action Bar */}
                <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 sticky top-20 z-40 bg-[#0f172a]/90 backdrop-blur py-2 border-b border-slate-800/0">
                    
                    {/* Tabs */}
                    <div className="flex flex-wrap justify-center gap-2">
                        {TABS.map((tab) => {
                            const Icon = tab.icon;
                            const isActive = activeTab === tab.id;
                            return (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={clsx(
                                        "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all border",
                                        isActive 
                                            ? "bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-900/50" 
                                            : "bg-slate-900/50 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-600"
                                    )}
                                >
                                    <Icon className="w-4 h-4" />
                                    {tab.label}
                                </button>
                            );
                        })}
                    </div>

                    {/* Report Button */}
                    <button
                        onClick={handleGenerateReport}
                        disabled={isGeneratingReport}
                        className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium bg-emerald-600/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-600/20 hover:text-emerald-300 transition-all ml-0 md:ml-4"
                    >
                        {isGeneratingReport ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <FileDown className="w-4 h-4" />
                        )}
                        {isGeneratingReport ? 'Drafting Doc...' : 'Export Strategy'}
                    </button>
                </div>

                {/* Stage Content */}
                <div className="min-h-[600px]">
                    {activeTab === 'stage1' && <Stage1Intent data={result.stage1} />}
                    {activeTab === 'stage2' && <Stage2Goals data={result.stage2} />}
                    {activeTab === 'stage3' && <Stage3Strategy data={result.stage3} />}
                    {activeTab === 'stage4' && <Stage4RoadmapView data={result.stage4} />}
                    {activeTab === 'stage5' && <Stage5RisksView data={result.stage5} />}
                    {activeTab === 'stage6' && <Stage6SummaryView data={result.stage6} />}
                </div>

                <div className="text-center mt-12 pt-12 border-t border-slate-800">
                     <p className="text-slate-600 text-sm">System generated via Gemini 2.0 Flash & Pro models.</p>
                </div>

            </div>
        )}
      </main>
    </div>
  );
}